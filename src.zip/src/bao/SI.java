package bao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class SI {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column
private int id;
@Column
private float p;
@Column
private float r;
@Column
private float t;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public float getP() {
	return p;
}
public void setP(float p) {
	this.p = p;
}
public float getR() {
	return r;
}
public void setR(float r) {
	this.r = r;
}
public float getT() {
	return t;
}
public void setT(float t) {
	this.t = t;
}



}
